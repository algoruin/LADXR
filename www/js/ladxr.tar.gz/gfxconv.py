from patches import aesthetics
import sys

data = aesthetics.imageTo2bpp(sys.argv[1])
open(sys.argv[2], "wb").write(data)
