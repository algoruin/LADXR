import roomEditor
import romTables
import random

STATIC_NPC = {0x70, 0x71, 0x72, 0x73, 0xD0, 0xD1, 0xD2, 0x3E, 0x54}
BLOCK_LIST = {
    0x00: [(5, 5)],
    0x07: [(4, 4)],
    0x08: [(1, 2), (2, 2), (8, 2)],
    0x09: [(1, 2), (2, 2)],
    0x0E: [(5, 5)],
    0x8C: [(1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (2, 2), (3, 2), (4, 2), (5, 2), (7, 3)],
    0x2D: [(5, 5)],
    0x24: [(5, 2)],
    0x44: [(4, 3)],
    0xBC: [(6, 4)],
    0xA0: [(5, 6)],
    0xD4: [(8, 2)],
    0x34: [(5, 6)],
}

rom = romTables.ROMWithTables(open("input.gbc", "rb"))
overworld = [[0 for n in range(16*8)] for n in range(16*10)]
flags = [[0 for n in range(16*8)] for n in range(16*10)]
for y in range(16):
    for x in range(16):
        re = roomEditor.RoomEditor(rom, x + y * 16)
        tiles = re.getTileArray()
        for ty in range(8):
            for tx in range(10):
                overworld[x*10+tx][y*8+ty] = tiles[tx+ty*10]
                if tiles[tx+ty*10] in {0xA0, 0xD4, 0x6F, 0xC5, 0x5E, 0xC2, 0xDA}:
                    flags[x*10+tx][y*8+ty+1] |= 16
        for ex, ey, eid in re.entities:
            flags[x*10+ex][y*8+ey] |= 16
            if eid in STATIC_NPC:
                flags[x*10+ex][y*8+ey-1] |= 16

for room, items in BLOCK_LIST.items():
    rx = room & 0x0F
    ry = room >> 4
    for x, y in items:
        flags[rx * 10 + x][ry * 8 + y] |= 16

PHY_TRAV = {0x00, 0x02, 0x03, 0x05, 0x06, 0x07, 0x08, 0x0A, 0x30, 0x50}
PHY_WALK = {0x00, 0x02, 0x05, 0x06, 0x08, 0x0A}

def flood(x, y):
    todo = [(x, y)]
    while todo:
        x, y = todo.pop()
        if flags[x][y] & 1:
            continue
        if physics[overworld[x][y]] not in PHY_TRAV:
            continue
        flags[x][y] |= 1
        if x > 0:
            todo.append((x - 1, y))
        if x < 16 * 10 - 1:
            todo.append((x + 1, y))
        if y > 0:
            todo.append((x, y - 1))
        if y < 16 * 8 - 1:
            todo.append((x, y + 1))



physics = rom.banks[8][0x0AD4:0x0AD4+0x100]
for y in range(16*8):
    for x in range(16*10):
        if physics[overworld[x][y]] == 0x03:
            flood(x, y)

for y in range(16*8):
    for x in range(16*10):
        if not (flags[x][y] & 1):
            continue
        if flags[x][y] & 16:
            continue
        if physics[overworld[x][y]] not in PHY_WALK:
            continue
        if overworld[x][y - 1] in {0xBA, 0xE1}:
            continue
        flags[x][y] |= 0x02

for y in range(16*8):
    for x in range(16*10):
        if (x % 10) == 0 or (x % 10) == 9:
            continue
        if (y % 8) == 0 or (y % 8) == 7:
            continue
        if not (flags[x][y] & 2):
            continue
        if not (flags[x][y+1] & 1) or physics[overworld[x][y+1]] not in PHY_WALK:
            continue
        if flags[x][y-1] & 1:
            left = (flags[x-1][y-1] & 1) and (flags[x-1][y] & 1) and (flags[x-1][y+1] & 1)
            right = (flags[x+1][y-1] & 1) and (flags[x-1][y] & 1) and (flags[x-1][y+1] & 1)
            if not left and not right:
                continue
        if flags[x+1][y] & 1 and not (flags[x+1][y+1] & 1):
            continue
        if flags[x-1][y] & 1 and not (flags[x-1][y+1] & 1):
            continue
        flags[x][y] |= 4
print(flags[65][4])
flags[65][4] = 0


all_option_tiles = []
for y in range(16*8):
    for x in range(16*10):
        if flags[x][y] & 4:
            all_option_tiles.append((x, y))

print("[")
for n in range(len(all_option_tiles)):
    print(f"{all_option_tiles[n]}, ", end='')
    if n % 8 == 7:
        print("")
print("]")


import PIL.Image, PIL.ImageDraw
result = PIL.Image.new("RGB", (16 * 161, 16 * 129))
result.putalpha(0)
draw = PIL.ImageDraw.Draw(result)
for y in range(16*8):
    for x in range(16*10):
        px = x * 16 + (x // 10)
        py = y * 16 + (y // 8)
        if flags[x][y] & 4:
            draw.rectangle([(px, py), (px + 15, py + 15)], outline=0xFFFF0000)
            draw.rectangle([(px+1, py+1), (px + 14, py + 14)], outline=0xFFFF0000)
        if flags[x][y] & 8:
            draw.rectangle([(px, py), (px + 15, py + 15)], outline=0xFF0000FF)
        if flags[x][y] & 32:
            draw.rectangle([(px, py), (px + 15, py + 15)], outline=0xFF000000)

result.save("/var/www/html/dump/_map/overlay.png")
