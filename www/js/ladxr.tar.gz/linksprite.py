import sys
import PIL.Image
import PIL.ImageDraw

def BA(bank, addr):
    return bank * 0x4000 + (addr & 0x3FFF)

img = PIL.Image.new("L", (17*0x11,17*9))
rom = open(sys.argv[1], "rb").read()
if len(sys.argv) > 2:
    rom = rom[:0x2C*0x4000] + open(sys.argv[2], "rb").read()
def paste(px, py, addr, attr):
    for y in range(16):
        a = rom[addr]
        b = rom[addr+1]
        addr += 2
        for x in range(8):
            c = 0
            bit = (0x01 << x) if attr & 0x20 else (0x80 >> x)
            if a & bit:
                c |= 1
            if b & bit:
                c |= 2
            if attr & 0x40:
                img.putpixel((px+x, py+15-y), c * 0x40)
            else:
                img.putpixel((px+x, py+y), c * 0x40)

for n in range(0x77):
    if n in {0x02, 0x03, 0x08, 0x09, 0x0C, 0x0D, 0x5A, 0x5D}:
        continue
    idx1 = rom[BA(0x20, 0x5319 + n * 2)]
    attr1 = rom[BA(0x20, 0x5407 + n * 2)]
    idx2 = rom[BA(0x20, 0x531A + n * 2)]
    attr2 = rom[BA(0x20, 0x5408 + n * 2)]
    paste(16 + (n % 16) * 17,  16 + n // 16 * 17, BA(0x2C, 0x5800 + idx1 * 16), attr1)
    paste(16 + (n % 16) * 17 + 8, 16 + n // 16 * 17, BA(0x2C, 0x5800 + idx2 * 16), attr2)

draw = PIL.ImageDraw.Draw(img)
for n in range(16):
    draw.text((18+n*17, 0), f"x{n:X}", fill=255)
    draw.text((2, 18+n*17), f"{n:X}x", fill=255)
img = img.resize((img.size[0] * 3, img.size[1] * 3), PIL.Image.NEAREST)
img.save("/var/www/html/dump/link.png")
