
def xyrange(w, h):
    for y in range(h):
        for x in range(w):
            yield x, y
