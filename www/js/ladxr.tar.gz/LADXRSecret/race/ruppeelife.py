from roomEditor import RoomEditor
from assembler import ASM
import utils


def prePatch(rom):
    pass

def postPatch(rom):
    rom.patch(0x02, 0x238F, ASM("""
        ld   a, [$DB5A]
        and  a
        jr   z, $04
        dec  a
        ld   [$DB5A], a
    """), ASM("""
        ; Subtract rupees instead of hearts
        ld   a, [$DB92]
        add  a, 20
        ld   [$DB92], a
    """), fill_nop=True)
    rom.patch(0x02, 0x227E, ASM("ldh [$FFF3], a"), "", fill_nop=True)

    # Change all heart drops into rupees
    rom.patch(0x20, 0x0087, "385d03", "9e6003")

    # Tick down rupees and kill the player when it reaches zero
    rom.patch(0x00, 0x0367, ASM("call $0091"), ASM("call $00B8"))
    re = RoomEditor(rom, 0x2a3)
    warp = re.getWarps()[0]
    rom.patch(0x00, 0x00B8, "00" * 0x48, ASM("""
        ld   a, [$DB95] ;Get the gameplay type
        cp   $0B
        jp   nz, $0091

        ; Check if the timer expired
        ld   hl, $FF0F
        bit  2, [hl]
        jp   z, $0091
        
        ; Check if we have a full second passed
        call $27D0 ; Enable SRAM
        ld   hl, $B000
        ld   a, [hl]
        and  a
        jp   nz, $0091
        
        ; Setup rupee decrease
        ld   hl, $DB92
        inc  [hl]

        ld   hl, $DB5D
        ldi  a, [hl]
        or   [hl]
        jp   nz, $0091
        
        ; Kill the player
        ld   [$DB5A], a
        
        ; Set rupees to 100*hearts
        ld   a, [$DB5B]
        cp   $09
        jr   c, noMax
        ld   a, $09
noMax:
        ld   [$DB5D], a
        
        ; Reset save location
        ld   hl, $DB5F
        xor  a
        ldi  [hl], a
        ldi  [hl], a
        ld   a, $%02x ; Room
        ldi  [hl], a
        ld   a, $%02x ; X
        ldi  [hl], a
        ld   a, $%02x ; Y
        ldi  [hl], a

        jp $0091
    """ % (warp.room, warp.target_x, warp.target_y)), fill_nop=True)

    rom.banks[0x2C][0x0A90:0x0AA0] = rom.banks[0x2C][0x0CF0:0x0D00]
    rom.banks[0x2C][0x0CD0:0x0CE0] = rom.banks[0x2C][0x0CF0:0x0D00]
    rom.banks[0x2C][0x0CE0:0x0CF0] = rom.banks[0x2C][0x0CF0:0x0D00]

    rom.banks[0x32][0x3DD0:0x3DE0] = rom.banks[0x2C][0x0CF0:0x0D00]
    rom.banks[0x32][0x3DE0:0x3DF0] = rom.banks[0x2C][0x0CF0:0x0D00]

    rom.patch(0x01, 0x1394, ASM("""
        ld   a, $30
        ld   [$DB78], a ; max arrows
        ld   a, $30
        ld   [$DB77], a ; max bombs
        ld   a, $20
        ld   [$DB76], a ; max powder
    """), ASM("""
        ld   hl, $DB76
        ld   a, $20
        ldi  [hl], a
        ld   a, $30
        ldi  [hl], a
        ldi  [hl], a
        ld   a, $03
        ld   [$DB5D], a
    """))