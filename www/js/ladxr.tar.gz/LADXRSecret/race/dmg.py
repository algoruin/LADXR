from assembler import ASM


def prePatch(rom):
    pass

def toRGB(a, b):
    r = a & 0x1F
    g = (a & 0xE0) >> 5 | ((b & 0x03) << 3)
    b = ((b >> 2) & 0x1F)
    return r, g, b

def fromRGB(r, g, b):
    return r | ((g & 0x07) << 5), (g >> 3) | (b << 2)

DMG = [(2, 5, 7), (10, 17, 14), (21, 26, 18), (29, 31, 25)]

def updatePal(rom, bank, start, end):
    assert (end - start) % 8 == 0
    for n in range(start, end, 8):
        pal = rom.banks[bank][n:n+8]
        CGB = []
        for m in range(0, 8, 2):
            CGB.append(toRGB(pal[m], pal[m + 1]))
        lookup = [3, 2, 1, 0]
        if max(*CGB[1]) < max(*CGB[3]):
            lookup = [3, 0, 1, 2]
        for m in range(0, 8, 2):
           pal[m], pal[m + 1] = fromRGB(*DMG[lookup[m // 2]])
        rom.banks[bank][n:n + 8] = pal

def postPatch(rom):
    for x in range(256):
        for y in range(128):
            r, g, b = toRGB(x, y)
            assert 0 <= r <= 32
            assert 0 <= g <= 32
            assert 0 <= b <= 32
            assert fromRGB(r, g, b) == (x, y), "%s %s" % (fromRGB(r, g, b), (x, y))

    # Main palettes
    updatePal(rom, 0x21, 0x1518, 0x34F0)
    # Intro palettes
    updatePal(rom, 0x21, 0x3536, 0x3E6E)
    # Inventory menu
    updatePal(rom, 0x20, 0x1D61, 0x1DE1)
