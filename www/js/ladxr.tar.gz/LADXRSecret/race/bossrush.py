from roomEditor import RoomEditor, ObjectWarp
from assembler import ASM
import utils


def prePatch(rom):
    pass

def postPatch(rom):
    re = RoomEditor(rom, 0x274)
    re.entities = [(4, 1, 0x36)]
    re.objects.append(ObjectWarp(1, 8, 0x70, 0x50, 0x7c))
    re.store(rom)
    rom.room_sprite_data_indoor[0x274-0x100] = b'\xff\xff\xff\xff'

    
    rom.patch(0x20, 0x00a2, ASM("dw $59DC"), ASM("dw $7FF5"))
    rom.patch(0x03, 0x3FF5, "00" * 11, ASM("""
        ldh  a, [$FFF7]  ; Check if we are in the egg
        cp   $08
        jp   nz, $59DC ; normal heart container
        jp   $3FF0
    """), fill_nop=True)

    rom.patch(0x00, 0x3FF0, "00" * 0x10, ASM("""
        ld   a, $3D
        call $080C ; switch bank
        jp   $7000
    """), fill_nop=True)
    rom.patch(0x3D, 0x3000, "00" * 0x1000, ASM("""
        ; force update tilesets
        xor  a
        ld   [$C197], a
        ld   a, $01
        ldh  [$FF91], a
        ld   a, $03
        ld   [$C10D], a
        ld   a, $01
        ld   [$C10E], a

        ld   hl, $C193
        ld   a, $FF
        ldi  [hl], a
        ldi  [hl], a
        ldi  [hl], a
        ldi  [hl], a

        ld   a, $23 ; final boss music
        ld   [$D368], a
    
        ld   a, [$C1BD] ; did boss intro
        inc  a
        ld   [$C1BD], a ; did boss intro
        rst  0
        dw   $0000
        
        dw   SpawnRollingBones
        dw   SpawnDelay ; we need some delay for the rolling bones to be properly destroyed
        dw   SpawnHinox
        dw   SpawnDodongo
        dw   SpawnCueball
        dw   SpawnGhoma
        dw   SpawnSmasher
        ;dw   SpawnGrimCreeper ; Does not work correctly...
        dw   SpawnBlaino
        
        dw   SpawnAvalaunch
        dw   SpawnGiantBuzzBlob
        dw   SpawnMoblinKing
        dw   SpawnArmos
        dw   SpawnCuccu
        
        dw   SpawnMoldorm
        dw   SpawnGenie
        dw   SpawnSlimeEye
        dw   SpawnAnglerFish
        dw   SpawnSlimeEel
        dw   SpawnFacade
        dw   SpawnEvilEagle
        dw   SpawnHotHead
        dw   SpawnNightmare

setMinibossPositionAndDrop:
        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $28
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $30
        ld   hl, $C4E0 ; entity drop item
        add  hl, de
        ld   [hl], $36 ; drop the next boss...
        ret

SpawnRollingBones:
        ld   a, $81
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop

        ld   a, $82
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop

        ld   a, $AB
        ld   [$C193 + 2], a
        ld   a, $AB
        ld   [$C193 + 3], a

        jp   $3F8D     ; unload entity

SpawnDelay:
        ld   a, $36 
        call $3B86 ; spawn new entity
        jp   $3F8D     ; unload entity

SpawnHinox:
        ld   a, $89
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $54
        ld   [$C193 + 2], a
        jp   $3F8D     ; unload entity

SpawnDodongo:
        ld   a, $60
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $AA
        ld   [$C193 + 2], a
        ld   a, $AA
        ld   [$C193 + 3], a
        jp   $3F8D     ; unload entity

SpawnCueball:
        ld   a, $8E
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $56
        ld   [$C193 + 2], a
        jp   $3F8D     ; unload entity

SpawnGhoma:
        ld   a, $5e
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $a8
        ld   [$C193 + 2], a
        jp   $3F8D     ; unload entity

SpawnSmasher:
        ld   a, $92
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $57
        ld   [$C193 + 2], a
        jp   $3F8D     ; unload entity

SpawnGrimCreeper:
        ld   a, $bc
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $A9
        ld   [$C193 + 2], a
        jp   $3F8D     ; unload entity

SpawnBlaino:
        ld   a, $be
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $A7
        ld   [$C193 + 2], a
        jp   $3F8D     ; unload entity

SpawnAvalaunch:
        ld   a, $f4
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $08
        ld   [$C193 + 0], a
        ld   a, $09
        ld   [$C193 + 1], a
        ld   a, $0A
        ld   [$C193 + 2], a
        jp   $3F8D     ; unload entity

SpawnGiantBuzzBlob:
        ld   a, $f8
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $0B
        ld   [$C193 + 0], a
        ld   a, $0C
        ld   [$C193 + 1], a
        ld   a, $0D
        ld   [$C193 + 2], a
        jp   $3F8D     ; unload entity

SpawnMoblinKing:
        ld   a, $e4
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $80
        ld   [$C193 + 1], a
        ld   a, $A5
        ld   [$C193 + 3], a
        jp   $3F8D     ; unload entity

SpawnArmos:
        ld   a, $88
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        ld   a, $53
        ld   [$C193 + 3], a
        jp   $3F8D     ; unload entity

SpawnCuccu:
        ld   a, $6C
        call $3B86 ; spawn new entity
        call setMinibossPositionAndDrop
        jp   $3F8D     ; unload entity

SpawnMoldorm:
        ld   a, $59
        call $3B86 ; spawn new entity

        ; sprites
        ld   a, $B0
        ld   [$C193 + 2], a
        ld   a, $B1
        ld   [$C193 + 3], a

        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $28
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $30
        
        jp   $3F8D     ; unload entity

SpawnGenie:
        ld   a, $5C
        ld   e, $05
        call $3B98 ; spawn new entity in range (needs to be in a low sprite slot)

        ; sprites
        ld   a, $B6
        ld   [$C193 + 2], a
        ld   a, $B7
        ld   [$C193 + 3], a

        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $48
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $30
        jp   $3F8D     ; unload entity

SpawnSlimeEye:
        ld   a, $5B
        call $3B86 ; spawn new entity

        ; sprites
        ld   a, $B4
        ld   [$C193 + 2], a
        ld   a, $B5
        ld   [$C193 + 3], a

        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $48
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $30
        jp   $3F8D     ; unload entity

SpawnAnglerFish:
        ld   a, $65
        call $3B86 ; spawn new entity

        ; sprites
        ld   a, $AC
        ld   [$C193 + 0], a
        ld   a, $AD
        ld   [$C193 + 1], a
        ld   a, $AE
        ld   [$C193 + 2], a
        ld   a, $AF
        ld   [$C193 + 3], a

        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $78
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $00
        jp   $3F8D     ; unload entity

SpawnSlimeEel:
        ld   a, $5D
        call $3B86 ; spawn new entity

        ; sprites
        ld   a, $B8
        ld   [$C193 + 2], a
        ld   a, $B9
        ld   [$C193 + 3], a

        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $48
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $30
        
        ld   a, $60
        ld   [$DBB2], a ; set map entry position so we do not fall in the hole
        jp   $3F8D     ; unload entity

SpawnFacade:
        ld   a, $5A
        call $3B86 ; spawn new entity

        ; sprites
        ld   a, $66
        ld   [$C193 + 0], a
        ld   a, $B2
        ld   [$C193 + 2], a
        ld   a, $B3
        ld   [$C193 + 3], a

        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $50
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $48
        jp   $3F8D     ; unload entity

SpawnEvilEagle:
        ld   a, $63
        ld   e, $05
        call $3B98 ; spawn new entity in range (needs to be in a low sprite slot)

        ; sprites
        ld   a, $bc
        ld   [$C193 + 0], a
        ld   a, $bd
        ld   [$C193 + 1], a
        ld   a, $be
        ld   [$C193 + 2], a
        ld   a, $bf
        ld   [$C193 + 3], a

        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $50
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $B8
        jp   $3F8D     ; unload entity

SpawnHotHead:
        ld   a, $62
        call $3B86 ; spawn new entity

        ; sprites
        ld   a, $ba
        ld   [$C193 + 2], a
        ld   a, $bb
        ld   [$C193 + 3], a

        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $50
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $78
        jp   $3F8D     ; unload entity

SpawnNightmare:
        ld   a, $E6
        call $3B86 ; spawn new entity

        ; sprites
        ld   a, $e8
        ld   [$C193 + 0], a
        ld   a, $e9
        ld   [$C193 + 1], a
        ld   a, $ea
        ld   [$C193 + 2], a
        ld   a, $eb
        ld   [$C193 + 3], a

        ld   hl, $C200 ; entity X
        add  hl, de
        ld   [hl], $50
        ld   hl, $C210 ; entity Y
        add  hl, de
        ld   [hl], $78
        jp   $3F8D     ; unload entity
    """, 0x7000), fill_nop=True)

    # rom.texts[0x0ce] = utils.formatText("Hoot! Young lad, I mean... #####, the hero! You have defeated the Nightmares! You have proven your wisdom, courage and power! ... ... ... ... But, there are more secrets to uncover, hidden, special secrets... Thank you, #####... My work is done... The Wind Fish will wake soon. Good bye...Hoot!")
    # rom.texts[0x0cf] = rom.texts[0x0ce]
    # rom.texts[0x0d0] = utils.formatText("... ... ... ...  ... ... ... ...  I AM THE WIND       FISH...  LONG HAS BEEN   MY SLUMBER...  DID YOU FIND ANY EXTRA SECRETS, THERE ARE MORE THINGS HIDDEN IN MY DREAMS ... ... ... ...   BUT, VERILY, IT BE THE NATURE   OF DREAMS TO END! WHEN I DOST AWAKEN, KOHOLINT  WILL BE GONE... ONLY THE MEMORY  OF THIS DREAM LAND WILL EXIST   IN THE WAKING       WORLD...  SOMEDAY, THOU MAY RECALL THIS  ISLAND...  THAT  MEMORY MUST BE  THE REAL DREAM      WORLD... ... ... ... ...  COME, #####... LET US AWAKEN...    TOGETHER!!")
    # rom.texts[0x0d1] = rom.texts[0x0d0]
