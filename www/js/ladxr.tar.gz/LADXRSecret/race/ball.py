from assembler import ASM


def prePatch(rom):
    pass

def postPatch(rom):
    rom.patch(0x00, 0x3817, 0x3826, ASM("""
    jr end
rentry:
    ld   hl, $4000 ; OverworldEntitiesPointersTable
    ld   a, [$DBA5] ; wIsIndoor
    and  a
    jr   z, $3868 + rentry - rentry ; .pointersTableEnd
    
    ld   h, $42 ; IndoorsAEntitiesPointersTable
    jr   $3853 + rentry - rentry
end:
              """, 0x3817), fill_nop=True)
    rom.patch(0x00, 0x3850, 0x3853, ASM("jp $3819"))

    rom.banks[0x3F][0x3F00:0x4000] = rom.banks[0x31][0x2600:0x2700]
    rom.patch(0x07, 0x2003, "4E004E20", "FE0BFE2B")

    # There is a empty hole in bank0 around ~700 due to the graphics loading patches, so use that.
    rom.patch(0x00, 0x19D5, 0x19D9, ASM("jp $0767"), fill_nop=True)
    rom.patch(0x00, 0x0767, "00" * 19, ASM("""
        ld   a, [$DBAE] ; wIndoorRoom  
        ld   [de], a
        ld   hl, $DB6F ; wWreckingBallRoom
        ld   de, $DB61 ; wSpawnMapRoom
        ld   c, $03
loop:
        ld   a, [de]
        inc  de
        ldi  [hl], a
        dec c
        jr  nz, loop
        ret
    """), fill_nop=True)
